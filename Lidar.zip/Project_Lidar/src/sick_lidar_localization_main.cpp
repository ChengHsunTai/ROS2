#include <iostream>
#include <sick_lidar_localization/sick_lidar_localization.h>
#include <thread>
#include <limits>
#include <tcp_sender.h>

int sock;

int main(int argc, char** argv){
    
    rosNodePtr node = 0;
    bool launchfile_ok = sick_lidar_localization::API::parseLaunchfileSetParameter(node, argc,argv);
    
    
    sick_lidar_localization::Config config; // default configuration
    sick_lidar_localization::API::getParams(node, config);
    sick_lidar_localization::API lidar_loc_api;
    
    if (!lidar_loc_api.init(node, config))
    {
        ROS_ERROR_STREAM("## ERROR sick_lidar_localization::API::init() failed, aborting... ");
        exit(EXIT_FAILURE);
    }

//-------------------TCPmessage----------------------------------
    sock = socket(AF_INET, SOCK_STREAM, 0);
    if (sock < 0){
        std::cerr << "Error creating socket" << std::endl;
    }else {
        printf("socket created successfully\n");
    }

    const char *server_ip = "168.192.0.1";
    const int port = 2122;

    struct sockaddr_in server_address;
    server_address.sin_family = AF_INET;
    server_address.sin_port = htons(port);
    if (inet_pton(AF_INET, server_ip, &server_address.sin_addr) <= 0) {
        std::cerr << "Invalid address/Address not supported" << std::endl;
    }

    if (connect(sock, (struct sockaddr*)&server_address, sizeof(server_address)) < 0) {
        std::cerr << "Connection failed" << std::endl;
    }

    std::cout << "Connected to " << server_ip << ":" << port << std::endl;
//-------------------TCPmessage----------------------------------------------------------------

    std::this_thread::sleep_for(std::chrono::seconds(std::numeric_limits<int>::max()));



    ROS_INFO_STREAM("sick_lidar_localization finished.");
    lidar_loc_api.close();

}
