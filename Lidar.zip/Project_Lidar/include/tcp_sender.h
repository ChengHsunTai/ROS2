#include <iostream>
#include <cstring>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <string.h>


void int_to_hex(){
    
}

class SendTCP{
private:
    // set LiDAR_LOC's IP and port number 
    const char *server_ip = "168.192.0.1";
    const int port = 2122;
public:
    SendTCP() {}

    ~SendTCP() {}


    void Open_Session(int sock){
        const char* cola2_open_session = "\x02\x02\x02\x02" // STX
                                     "\x00\x00\x00\x0E"  // Length: 13 bytes
                                     "\x00\x00"          // Hub and NoC
                                     "\x00\x00\x00\x00"  // SessionID
                                     "\x00\x01"          // ReqID
                                     "\x4F\x58"          // Cmd = "O", Mode = "X"
                                     "\x1E"              // Timeout = 30 sec
                                     "\x00\x01"
                                     "\x00";         // ClientID Length = 0, ClientID Flexstring = 0
        printf("session open up\n");
        send(sock, cola2_open_session, 22, 0);

        char response[1024];
        int bytes_received = recv(sock, response, sizeof(response), 0);
        printf("byte = %d\n", bytes_received);
        if (bytes_received > 0) {
            std::cout << "Received response for session open: ";
            for (int i = 0; i < bytes_received; ++i) {
                printf("%02X ", (unsigned char)response[i]);
            }
            std::cout << std::endl;
        }
    }


};